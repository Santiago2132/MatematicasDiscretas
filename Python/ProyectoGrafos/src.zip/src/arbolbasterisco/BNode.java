package arbolbasterisco;

import java.util.Comparator;

public class BNode<T> {

    private int tam;
    private T[] claves;
    private BNode<T>[] almacenarHijos;

    //Constructor 
    public BNode(int numeroMaxClavesNodo) {
        this.tam = 0;
        this.claves = (T[]) new Object[numeroMaxClavesNodo];
        this.almacenarHijos = (BNode<T>[]) new BNode[numeroMaxClavesNodo + 1];
    }

    //En este metodo se comprueba si el nodo es una hoja 
    public boolean verificarHoja() {
        
        return almacenarHijos[0] == null;
    }

    //En este metodo se comprueba si el nodo está lleno 
    public boolean verificarNodoLleno() {
        
        return tam == claves.length;
    }

    //GETTERS AND SETTERS
    //Devuelve el tamaño, es decir, la cantidad de claves que tiene el nodo
    public int getTam() {
        
        return tam;
    }

    //Devuelve la posicion de la clave en el arreglo de las claves del nodo
    public T getClaves(int i) {
        
        return claves[i];
    }
    
    //Devuelve el padre del nodo
    public BNode<T> getPadre() {
       
        if (almacenarHijos[0] == null) {
            return null;
        } else {
            return almacenarHijos[0].getPadre();
        }
    }
    
    //Permite establecer el padre del nodo
    public void setPadre(BNode<T> padre) {
       
        if (almacenarHijos[0] != null){
            almacenarHijos[0].setPadre(padre);
            System.out.println("Se estableció el padre: " + padre);
        } else{
            this.almacenarHijos[0] = padre;
        }
        
    }

    //Devuelve el hijo de la posicion indicada en el arreglo de almacenar hijos
    public BNode<T> getAlmacenarHijos(int i) {
        
        return almacenarHijos[i];
    }

    //Permite establecer el hijo en la posicion indicada en el arreglo
    public void setAlmacenarHijos(int i, BNode<T> hijo) {
        
        almacenarHijos[i] = hijo;
        
        if (hijo != null) {
            hijo.setPadre(this);
        }
    }

    //OPERACIONES A REALIZAR EN EL NODO
    //Se inserta una clave en el nodo de forma ascendente, desplazando las otras claves a la derecha
    public void insertar(T clave) {
        
        int i = tam - 1;
        while (i >= 0 && claves[i] == null && comparar(clave, claves[i]) < 0) {
            claves[i + 1] = claves[i];
            i--;
        }
        
        claves[i + 1] = clave;
        tam++;
    }

    //Se ingresa una clave y la busca en los nodos
    public T buscar(T clave) {
        
        int i = 0;
        
        while (i < tam && (claves[i] == null || claves[i].equals(clave))) {
            i++;
        }
        
        if (i < tam && claves[i].equals(clave)) {
            return claves[i];
        } else {
            return null;
        }
    }

    //Se ingresa una clave y la elimina del nodo, desplazando las otras claves a la izquierda
    public void eliminar(T clave) {
        
        int i = 0;
        
        while (i < tam && (claves[i] == null || claves[i].equals(clave))) {
            i++;
        }
        
        if (i < tam && claves[i].equals(clave)) {
            while (i < tam - 1) {
                claves[i] = claves[i + 1];
                    i++;
            }
            
            claves[tam - 1] = null;
            tam--;
        }
    }
    
    //Divide los nodos por la mitad y crea un nuevo nodo en el que se insertan las claves mayores 
    public BNode<T> dividirNodos() {
            
        int medio = tam / 2;
        BNode<T> nodoNuevo = new BNode<>(claves.length);
        
        for (int i = medio; i < tam; i++) {
            nodoNuevo.insertar(claves[i]);
            claves[i] = null;
        }
        
        tam = medio;
        return nodoNuevo;
    }

    //Une un nodo con otro nodo e inserta las claves del otro nodo en el actual, estableciendo los hijos correspondientemente
    public void unirNodos(BNode<T> nodo) {
        
        for (int i = 0; i < nodo.tam; i++) {
            insertar(nodo.claves[i]);
        }
        
        for (int i = 0; i <= nodo.tam; i++) {
            setAlmacenarHijos(tam - nodo.tam + i, nodo.almacenarHijos[i]);
        }
    } 
 
    //Metodo para comparar los objetos. Se usa en el metodo de insertar
    public int comparar(T objeto1, T objeto2) {
        
        // Se verifica si los objetos son null
        if (objeto1 == null && objeto2 == null) {
            return 0;
        } else if (objeto1 == null) {
            return -1;
        } else if (objeto2 == null) {
            return 1;
        }
        
        Comparator comparador = Comparator.naturalOrder();
        
        //Se utiliza el comparador para comparar los objetos
        return comparador.compare(objeto1, objeto2);
    }
    
}