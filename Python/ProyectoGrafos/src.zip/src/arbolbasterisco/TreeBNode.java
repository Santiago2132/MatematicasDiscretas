package arbolbasterisco;

import arbolbasterisco.BNode;

public class TreeBNode <T> {
    
    private static final int topeDeClavesPorNodo = 4;

    private int numeroMaxClavesNodo;
    private int numeroMinClavesNodo;
    private int tam;
    private BNode<T> raiz;

    //Constructor
    public TreeBNode() {
        this(topeDeClavesPorNodo);
    }

    //Constructor
    public TreeBNode(int numeroMaxClavesNodo) {
        this.numeroMaxClavesNodo = numeroMaxClavesNodo;
        this.numeroMinClavesNodo = numeroMaxClavesNodo / 2;
        this.tam = 0;
        this.raiz = new BNode<>(numeroMaxClavesNodo);
    }

    //Metodo que llama al principal para insertar un objeto en el nodo
    public void llamarInsertar(T objeto) {
        
        insertar(raiz, objeto);
        tam++;
        
        if (raiz.verificarNodoLleno()) {
            dividirRaiz();
        }
    }

    //Metodo principal para insertar el objeto en el nodo
    private void insertar(BNode<T> nodo, T objeto) {
        
        if (nodo.verificarHoja()) {
            nodo.insertar(objeto);
            
            if (nodo.verificarNodoLleno()) {
                dividirNodo(nodo);
            }
            
        } else {
            
            int i = 0;
            
            while (i < nodo.getTam() && nodo.getClaves(i).toString().compareTo(objeto.toString())< 0 ) {
                i++;
            }
            
            insertar(nodo.getAlmacenarHijos(i), objeto);
            
            if (nodo.getAlmacenarHijos(i).verificarNodoLleno()) {
                splitNode(nodo, i);
            }
        }
    }

    //Metodo que llama al principal para buscar un objeto en el nodo
    public T llamarBusqueda(T objeto) {
        return busqueda(raiz, objeto);
    }

    //Metodo principal para buscar un objeto en el nodo
    private T busqueda(BNode<T> nodo, T objeto) {
        
        if (nodo.verificarHoja()) {
            return nodo.buscar(objeto);
        } else {
        
            int i = 0;
            
            while (i < nodo.getTam() && nodo.getClaves(i).toString().compareTo(objeto.toString()) < 0) {
                i++;
            }
            
            return busqueda(nodo.getAlmacenarHijos(i), objeto);
        }
    }

    //Metodo que llama al principal para insertar un objeto en el nodo
    public void llamarEliminar(T value) {
        eliminar(raiz, value);
        tam--;
        if (raiz.getTam() == 0 && raiz.getAlmacenarHijos(0) != null) {
            raiz = raiz.getAlmacenarHijos(0);
        }
    }

    //Metodo principal para eliminar un objeto en el nodo
    private void eliminar(BNode<T> nodo, T objeto) {
        
        if (nodo.verificarHoja()) {
            nodo.eliminar(objeto);
        } else {
        
        int i = 0;
        
        while (i < nodo.getTam() && nodo.getClaves(i).toString().compareTo(objeto.toString()) < 0) {
            i++;
        }
        
        eliminar(nodo.getAlmacenarHijos(i), objeto);
        
        if (nodo.getAlmacenarHijos(i).getTam() < numeroMinClavesNodo) {
            mergeNodes(nodo, i);
        }
    }
}
    
    //Metodo para
    private void dividirRaiz() {
        
        BNode<T> izquierdo = new BNode<>(numeroMaxClavesNodo);
        BNode<T> derecho = new BNode<>(numeroMaxClavesNodo);
        
        izquierdo.setAlmacenarHijos(0, raiz);
        derecho.setAlmacenarHijos(0, raiz.dividirNodos());
        
        raiz = new BNode<>(numeroMaxClavesNodo);
        raiz.insertar(izquierdo.getClaves(izquierdo.getTam()- 1));
        raiz.setAlmacenarHijos(0, izquierdo);
        raiz.setAlmacenarHijos(1, derecho);
    }

    private void dividirNodo(BNode<T> nodo) {
        
        BNode<T> nuevoNodo = new BNode<>(numeroMaxClavesNodo);
        
        nuevoNodo.setAlmacenarHijos(0, nodo.dividirNodos());
        
        if (nodo == raiz) {
            raiz = new BNode<>(numeroMaxClavesNodo);
            raiz.insertar(nuevoNodo.getClaves(0));
            raiz.setAlmacenarHijos(0, nodo);
            raiz.setAlmacenarHijos(1, nuevoNodo);
        } else {
            BNode<T> padre = nodo.getPadre();
            int i = padre.getTam()- 1;
            while (i >= 0 && padre.getAlmacenarHijos(i) != nodo) {
                i--;
            }
            
            padre.insertar(nuevoNodo.getClaves(0));
            padre.setAlmacenarHijos(i + 1, nuevoNodo);
            
            if (padre.verificarNodoLleno()) {
                dividirNodo(padre);
            }
        }
    }

    private void splitNode(BNode<T> padre, int i) {
        
        BNode<T> nodo = padre.getAlmacenarHijos(i);
        BNode<T> nuevoNodo = new BNode<>(numeroMaxClavesNodo);
        
        nuevoNodo.setAlmacenarHijos(0, nodo.dividirNodos());
        
        padre.insertar(nodo.getClaves(nodo.getTam()- 1));
        padre.setAlmacenarHijos(i + 1, nuevoNodo);
        
        if (padre.verificarNodoLleno()) {
            dividirNodo(padre);
        }
    }

    private void mergeNodes(BNode<T> padre, int i) {
        
        BNode<T> izquierdo = padre.getAlmacenarHijos(i);
        BNode<T> derecho = padre.getAlmacenarHijos(i + 1);
        
        izquierdo.unirNodos(derecho);
        padre.eliminar(derecho.getClaves(0));
        padre.setAlmacenarHijos(i + 1, null);
        
        if (padre == raiz && padre.getTam()== 0) {
            raiz = izquierdo;
        }
    }
    
}
